#!/usr/bin/env bash
set -euo pipefail

# Post-setup patch for a working DLC 2.3.11 + TF 2.12 + torch import coexistence.
# TensorFlow 2.12 pins typing_extensions<4.6, but DLC imports torch via pose_tracking_pytorch,
# and torch 2.10 requires newer typing_extensions (TypeIs support).
# This script reapplies the known-good override after environment creation.
#
# Usage:
#   conda activate dlc_mouse
#   ./post_setup_dlc_tf_gpu.sh
#
# Optional explicit env name (uses conda run):
#   ./post_setup_dlc_tf_gpu.sh dlc_mouse

ENV_NAME="${1:-}"

run_pip() {
  python -m pip install --upgrade "typing_extensions==4.15.0"
}

if [[ -n "$ENV_NAME" ]]; then
  if command -v conda >/dev/null 2>&1; then
    conda run -n "$ENV_NAME" python -m pip install --upgrade "typing_extensions==4.15.0"
  else
    echo "ERROR: conda not found in PATH; activate the target env and rerun without arguments." >&2
    exit 1
  fi
else
  if [[ -z "${CONDA_PREFIX:-}" ]]; then
    echo "ERROR: No active conda environment. Run 'conda activate dlc_mouse' first, or pass the env name." >&2
    exit 1
  fi
  run_pip
fi

echo "typing_extensions override applied (4.15.0)."
echo "Note: pip may warn that TensorFlow 2.12.1 requires typing-extensions<4.6; this override is intentional."
