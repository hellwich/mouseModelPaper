# Recreate the DLC GPU environment (repo-ready, env-local CUDA/cuDNN)

This reproduces the **working** DeepLabCut multi-animal environment used in this project:

- DeepLabCut `2.3.11`
- TensorFlow `2.12.1` (GPU-capable)
- env-local CUDA runtime (`cudatoolkit=11.8` in conda env)
- env-local cuDNN runtime (`nvidia-cudnn-cu11==8.6.0.163` via pip wheel)
- conda hooks that:
  - enforce `PYTHONNOUSERSITE=1`
  - expose env-local CUDA/cuDNN libs via `LD_LIBRARY_PATH`

> This setup **does not modify your system-wide CUDA toolkit**. It only uses the system NVIDIA **driver** (normal/required for GPU access).

---

## Files in this folder

- `environment_dlc_tf_gpu.yml` — curated conda environment spec (base env + key pip deps)
- `post_setup_dlc_tf_gpu.sh` — final compatibility override (`typing_extensions==4.15.0`)
- `hooks/activate.d/dlc_mouse_env.sh` — conda activate hook
- `hooks/deactivate.d/dlc_mouse_env.sh` — conda deactivate hook

---

## Why a post-setup step is needed

`tensorflow==2.12.1` declares `typing-extensions<4.6`, but `deeplabcut` imports `torch` via `pose_tracking_pytorch`, and modern `torch` imports require a newer `typing_extensions` (e.g. `TypeIs`).

The empirically working setup is:

1. install DLC + TF 2.12.1
2. then **override** `typing_extensions` to `4.15.0`

This produces a pip compatibility warning, but works in practice for this DLC/TF setup.

---

## 1) Create the environment

```bash
conda env create -f environment_dlc_tf_gpu.yml
conda activate dlc_mouse
```

If conda solving is slow on your machine, create a tiny env first and then install from the YAML in stages. (The curated YAML is intentionally short to improve reproducibility.)

---

## 2) Install the conda hooks (activate/deactivate)

From this folder:

```bash
mkdir -p "$CONDA_PREFIX/etc/conda/activate.d" "$CONDA_PREFIX/etc/conda/deactivate.d"
cp hooks/activate.d/dlc_mouse_env.sh "$CONDA_PREFIX/etc/conda/activate.d/"
cp hooks/deactivate.d/dlc_mouse_env.sh "$CONDA_PREFIX/etc/conda/deactivate.d/"
```

Re-activate so the hook takes effect:

```bash
conda deactivate
conda activate dlc_mouse
```

---

## 3) Apply the post-setup compatibility override

```bash
./post_setup_dlc_tf_gpu.sh
```

(Alternatively, if not activated: `./post_setup_dlc_tf_gpu.sh dlc_mouse`)

---

## 4) Verify the environment and GPU visibility

```bash
python - <<'PY'
from importlib.metadata import version
import os, site
import tensorflow as tf
import torch, deeplabcut
print("PYTHONNOUSERSITE =", os.environ.get("PYTHONNOUSERSITE"))
print("ENABLE_USER_SITE =", site.ENABLE_USER_SITE)
print("typing_extensions =", version("typing_extensions"))
print("torch =", torch.__version__)
print("tensorflow =", tf.__version__)
print("deeplabcut =", deeplabcut.__version__)
print("GPUs =", tf.config.list_physical_devices("GPU"))
PY
```

Expected:

- `PYTHONNOUSERSITE = 1`
- `ENABLE_USER_SITE = False`
- DLC imports successfully
- TensorFlow sees at least one GPU (`/physical_device:GPU:0`)

While training, confirm runtime GPU usage with:

```bash
nvidia-smi
```

You should see a `python` process with significant GPU memory usage and nontrivial utilization.

---

## Notes / pitfalls

### If TensorFlow cannot see the GPU
You may see `Cannot dlopen some GPU libraries` and `[]` for GPU devices. This usually means:

- the conda activate hook is not installed or not active
- `LD_LIBRARY_PATH` is missing env-local CUDA/cuDNN paths
- the `nvidia-cudnn-cu11` wheel is not installed in this env

Check by re-activating the env and rerunning the verification step.

### If `torch` import fails with `TypeIs` from `typing_extensions`
TensorFlow likely downgraded `typing_extensions` again (e.g. after reinstalling `tensorflow==2.12.1`). Reapply:

```bash
./post_setup_dlc_tf_gpu.sh
```

### Why not use `conda env export` as the primary env file?
A raw export is too large and brittle (lots of transitive, platform-specific packages). Keep this curated YAML as the primary reproducibility spec, and optionally store a full export only as an archival snapshot.

---

## Typical usage after setup

```bash
conda activate dlc_mouse
python train_dlc_multi_mouse_engine.py --config /path/to/dlc_synth_project/config.yaml
```

For inference on new rendered videos:

```bash
python predict_dlc_multi_mouse_batch.py \
  --config /path/to/dlc_synth_project/config.yaml \
  --videos-dir /path/to/new_render_output \
  --destfolder /path/to/new_render_output/dlc_predictions \
  --n-tracks 2 \
  --animal-names mouse0,mouse1
```
